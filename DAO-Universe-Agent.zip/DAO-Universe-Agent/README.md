# DAO-Universe
DAO Universe is a project for creating decentralized investment funds on the Blockchain techonology
